from assets.interface.telas.tela_principal.tela_principal import mostrar_tela, frame1

def main():

    mostrar_tela(frame1)

if __name__ == "__main__":
    main()
