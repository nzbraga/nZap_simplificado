
def sessao_id():
    return "versao_teste"


def sessao_nome():
    return "versao_teste\n"

